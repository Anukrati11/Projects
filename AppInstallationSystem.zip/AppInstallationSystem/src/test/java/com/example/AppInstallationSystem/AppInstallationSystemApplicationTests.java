package com.example.AppInstallationSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppInstallationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
